/* Rocket Rivals — full 3D arena, WebGL graphics, authoritative online physics.
   No JavaScript graphics packages, CDNs, or external game assets required. */
(()=>{
'use strict';
const $=id=>document.getElementById(id);
const canvas=$('game');
const gl=canvas.getContext('webgl',{antialias:true,alpha:false,powerPreference:'high-performance'})||canvas.getContext('experimental-webgl');
if(!gl){$('toast').textContent='WebGL is not available in this browser.';$('toast').classList.add('show');return;}
const PI=Math.PI,TAU=PI*2;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const mix=(a,b,t)=>a.map((v,i)=>lerp(v,b[i],t));
const rgb=s=>[parseInt(s.slice(1,3),16)/255,parseInt(s.slice(3,5),16)/255,parseInt(s.slice(5,7),16)/255];
const C={floor:rgb('#102d35'),stripe:rgb('#123942'),stripe2:rgb('#0d303c'),mark:rgb('#4f96a5'),blue:rgb('#36baff'),blueLite:rgb('#85e5ff'),orange:rgb('#ff8b35'),orangeLite:rgb('#ffd095'),dark:rgb('#061225'),metal:rgb('#152947'),rail:rgb('#26566e'),white:rgb('#e7faff'),black:rgb('#070b16'),tire:rgb('#090d18'),turf:rgb('#123740'),roof:rgb('#4e7090'),glass:rgb('#091b32'),boost:rgb('#eaa344')};
let tGlobal=0,resizeW=1,resizeH=1;
function resize(){const ratio=Math.min(1.6,window.devicePixelRatio||1);const w=Math.max(1,Math.floor(canvas.clientWidth*ratio)),h=Math.max(1,Math.floor(canvas.clientHeight*ratio));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;}resizeW=w;resizeH=h;gl.viewport(0,0,w,h);}
window.addEventListener('resize',resize);resize();
const vs=`attribute vec3 aPos;attribute vec3 aNorm;
uniform mat4 uModel,uView,uProj;varying vec3 vNormal,vLocal;varying vec3 vWorld;
void main(){vec4 w=uModel*vec4(aPos,1.0);vWorld=w.xyz;vLocal=aPos;vNormal=normalize(mat3(uModel)*aNorm);gl_Position=uProj*uView*w;}`;
const fs=`precision mediump float;uniform vec3 uColor;uniform float uEmissive,uMode,uAlpha;varying vec3 vNormal,vLocal,vWorld;
void main(){vec3 n=normalize(vNormal);float lambert=max(0.0,dot(n,normalize(vec3(-0.4,0.88,-0.62))));
 float light=0.48+0.5*lambert;vec3 c=uColor;
 if(uMode>0.5 && uMode<1.5){vec3 p=normalize(vLocal);float seams=abs(sin(atan(p.z,p.x)*6.0))*abs(sin(acos(clamp(p.y,-1.0,1.0))*7.5));float d=smoothstep(.03,.22,seams);c=mix(vec3(.06,.14,.23),vec3(.9,.95,1.0),d);light=0.68+0.35*lambert;}
 if(uMode>1.5){float stripe=sin(vWorld.x*2.8+vWorld.z*1.9);c*=.94+.06*stripe;}
 c=c*light+uColor*uEmissive;gl_FragColor=vec4(c,uAlpha);}`;
function shader(type,src){const sh=gl.createShader(type);gl.shaderSource(sh,src);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));return sh;}
const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
const loc={pos:gl.getAttribLocation(program,'aPos'),norm:gl.getAttribLocation(program,'aNorm'),model:gl.getUniformLocation(program,'uModel'),view:gl.getUniformLocation(program,'uView'),proj:gl.getUniformLocation(program,'uProj'),color:gl.getUniformLocation(program,'uColor'),emit:gl.getUniformLocation(program,'uEmissive'),mode:gl.getUniformLocation(program,'uMode'),alpha:gl.getUniformLocation(program,'uAlpha')};
gl.enableVertexAttribArray(loc.pos);gl.enableVertexAttribArray(loc.norm);gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.clearColor(.013,.025,.055,1);
function mesh(verts,indices){const v=gl.createBuffer(),ind=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,v);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(verts),gl.STATIC_DRAW);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ind);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indices),gl.STATIC_DRAW);return {v,ind,n:indices.length};}
function boxMesh(){const v=[],ii=[];const sides=[[[0,0,1],[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]]],[[0,0,-1],[[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]]],[[1,0,0],[[1,-1,1],[1,-1,-1],[1,1,-1],[1,1,1]]],[[-1,0,0],[[-1,-1,-1],[-1,-1,1],[-1,1,1],[-1,1,-1]]],[[0,1,0],[[-1,1,1],[1,1,1],[1,1,-1],[-1,1,-1]]],[[0,-1,0],[[-1,-1,-1],[1,-1,-1],[1,-1,1],[-1,-1,1]]]];for(const [n,p]of sides){const start=v.length/6;for(const q of p)v.push(...q.map(a=>a*.5),...n);ii.push(start,start+1,start+2,start,start+2,start+3);}return mesh(v,ii);}
function sphereMesh(rows=20,cols=30){const v=[],ii=[];for(let r=0;r<=rows;r++){const phi=r*PI/rows;for(let c=0;c<=cols;c++){const theta=c*TAU/cols;const x=Math.sin(phi)*Math.cos(theta),y=Math.cos(phi),z=Math.sin(phi)*Math.sin(theta);v.push(x,y,z,x,y,z);}}for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){const a=r*(cols+1)+c,b=a+cols+1;ii.push(a,a+1,b,b,a+1,b+1);}return mesh(v,ii);}
function cylinderMesh(segments=16){const v=[],ii=[];for(let k=0;k<segments;k++){const a=k*TAU/segments,b=(k+1)*TAU/segments;const n=[Math.cos((a+b)*.5),0,Math.sin((a+b)*.5)],base=v.length/6;for(const p of [[Math.cos(a),-.5,Math.sin(a)],[Math.cos(b),-.5,Math.sin(b)],[Math.cos(b),.5,Math.sin(b)],[Math.cos(a),.5,Math.sin(a)]])v.push(...p,...n);ii.push(base,base+2,base+1,base,base+3,base+2);}for(const y of [-.5,.5]){const offset=v.length/6,normal=[0,Math.sign(y),0];v.push(0,y,0,...normal);for(let k=0;k<=segments;k++){const a=k*TAU/segments;v.push(Math.cos(a),y,Math.sin(a),...normal);}for(let k=0;k<segments;k++){if(y>0)ii.push(offset,offset+k+2,offset+k+1);else ii.push(offset,offset+k+1,offset+k+2);}}return mesh(v,ii);}
function ringMesh(segments=40){const v=[],ii=[];for(let i=0;i<=segments;i++){const a=i*TAU/segments;for(const radius of [.97,1.03])v.push(Math.sin(a)*radius,0,Math.cos(a)*radius,0,1,0);if(i<segments){const a=i*2;ii.push(a,a+1,a+2,a+2,a+1,a+3);}}return mesh(v,ii);}
const meshes={box:boxMesh(),sphere:sphereMesh(),cyl:cylinderMesh(),ring:ringMesh()};
function identity(){return [1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];}
function mul(a,b){const c=new Array(16);for(let j=0;j<4;j++)for(let i=0;i<4;i++)c[j*4+i]=a[i]*b[j*4]+a[i+4]*b[j*4+1]+a[i+8]*b[j*4+2]+a[i+12]*b[j*4+3];return c;}
function translation(x,y,z){const m=identity();m[12]=x;m[13]=y;m[14]=z;return m;}
function scaling(x,y,z){const m=identity();m[0]=x;m[5]=y;m[10]=z;return m;}
function rotY(a){const c=Math.cos(a),s=Math.sin(a);return [c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1];}
function rotX(a){const c=Math.cos(a),s=Math.sin(a);return [1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1];}
function rotZ(a){const c=Math.cos(a),s=Math.sin(a);return [c,s,0,0,-s,c,0,0,0,0,1,0,0,0,0,1];}
function M(x=0,y=0,z=0,sx=1,sy=1,sz=1,yaw=0,pitch=0,roll=0){let m=translation(x,y,z);if(yaw)m=mul(m,rotY(yaw));if(pitch)m=mul(m,rotX(pitch));if(roll)m=mul(m,rotZ(roll));return mul(m,scaling(sx,sy,sz));}
function perspective(fov,aspect,near,far){const f=1/Math.tan(fov/2),nf=1/(near-far);return [f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0];}
function lookAt(eye,target){let z=[eye[0]-target[0],eye[1]-target[1],eye[2]-target[2]];let n=Math.hypot(...z);z=z.map(q=>q/(n||1));let x=[z[2],0,-z[0]];n=Math.hypot(...x);x=x.map(q=>q/(n||1));const y=[z[1]*x[2]-z[2]*x[1],z[2]*x[0]-z[0]*x[2],z[0]*x[1]-z[1]*x[0]];return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-x.reduce((s,p,i)=>s+p*eye[i],0),-y.reduce((s,p,i)=>s+p*eye[i],0),-z.reduce((s,p,i)=>s+p*eye[i],0),1];}
function draw(name,model,color,emit=0,mode=0,alpha=1){const obj=meshes[name];gl.bindBuffer(gl.ARRAY_BUFFER,obj.v);gl.vertexAttribPointer(loc.pos,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(loc.norm,3,gl.FLOAT,false,24,12);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,obj.ind);gl.uniformMatrix4fv(loc.model,false,new Float32Array(model));gl.uniform3fv(loc.color,color);gl.uniform1f(loc.emit,emit);gl.uniform1f(loc.mode,mode);gl.uniform1f(loc.alpha,alpha);gl.drawElements(gl.TRIANGLES,obj.n,gl.UNSIGNED_SHORT,0);}
function cube(x,y,z,w,h,d,c,e=0){draw('box',M(x,y,z,w,h,d),c,e);}
function bar(x1,y1,z1,x2,y2,z2,r,color,em=.3){const dx=x2-x1,dy=y2-y1,dz=z2-z1;const L=Math.hypot(dx,dy,dz)||1;const pitch=Math.atan2(dy,Math.hypot(dx,dz));const yaw=Math.atan2(dx,-dz);draw('box',M((x1+x2)/2,(y1+y2)/2,(z1+z2)/2,r,r,L,yaw,pitch),color,em);}
const WORLD=[];const add=(shape,model,col,emit=0,mode=0)=>WORLD.push([shape,model,col,emit,mode]);
function wbox(x,y,z,sx,sy,sz,col,emit=0){add('box',M(x,y,z,sx,sy,sz),col,emit);}
function wring(x,y,z,r,col,emit=0){add('ring',M(x,y,z,r,1,r),col,emit);}
function wbar(x1,y1,z1,x2,y2,z2,r,col,emit=.2){const dx=x2-x1,dy=y2-y1,dz=z2-z1,len=Math.hypot(dx,dy,dz)||1;add('box',M((x1+x2)/2,(y1+y2)/2,(z1+z2)/2,r,r,len,Math.atan2(dx,-dz),Math.atan2(dy,Math.hypot(dx,dz))),col,emit);}
function buildWorld(){
 wbox(0,-.67,0,130,.7,130,C.dark);wbox(0,-.13,0,34.1,.26,50.1,C.floor);
 for(let i=0;i<10;i++)wbox(0,.004,-22.5+i*5,33.5,.012,4.97,i%2?C.stripe:C.stripe2);
 for(const sign of [-1,1]){
  wbox(sign*16.4,.034,0,.16,.035,49.7,C.mark,.30);wbox(0,.034,sign*24.15,33.2,.035,.12,C.mark,.28);
  wbox(sign*17.5,1.5,0,.55,3,51.1,C.metal);wbox(sign*17.0,2.95,0,.30,.18,51,C.blueLite,.5);
  wbox(sign*19.0,4.0,0,2,2.2,58,C.rail);wbox(sign*21.5,6.0,0,2.5,2,60,C.metal);wbox(sign*24,8.0,0,2.3,2,62,C.rail);
  for(let i=0;i<12;i++){const z=-26.5+i*4.9;wbox(sign*18.6,4,z,2,.07,.07,i%2?C.blue:C.orange,.6);wbox(sign*21.5,6.9,z,2,.10,.1,i%2?C.orange:C.blue,.38);}
  // Arena sides contain seamless transparent-look metal panelling and bumpers.
  for(let z=-22;z<=22;z+=5){wbox(sign*16.96,1.15,z,.13,1.9,.09,C.roof,.2);wbox(sign*16.9,.22,z,.19,.13,4.8,C.blue,.65);}
 }
 wbox(0,.045,0,.09,.038,49.3,C.mark,.15);wbox(0,.05,0,33.1,.02,.095,C.mark,.15);
 wring(0,.045,0,5.35,C.mark,.34);
 wring(0,.048,0,.43,C.white,.4);
 for(const sign of [-1,1]){
  // centre facing goal outlines and angular kickoff lines
  wbox(0,.042,sign*13.9,12,.024,.10,C.mark,.15);
  wbox(0,.044,sign*19.5,17,.025,.12,C.mark,.1);
  wbox(0,.041,sign*18.9,.10,.02,11,C.mark,.1);
  wring(0,.046,sign*13,2.3,C.mark,.14);
 }
 for(let side of [-1,1]){
  const z=side*25,back=side*28.5,col=side===1?C.blue:C.orange;
  wbox(0,.1,side*26.5,10.6,.14,6,C.dark);
  wbox(0,4.55,z,11.2,.19,.22,col,.7);
  for(const x of [-5.42,5.42]){
   wbox(x,2.25,z,.2,4.55,.25,col,.7);
   wbar(x,4.55,z,x,4.55,back,.13,col,.35);
   wbox(x,2.23,back,.13,4.5,.2,C.rail);
  }
  wbox(0,4.52,back,11,.12,.17,C.rail);
  // Back, roof, and side goal net mesh
  for(let x=-5;x<=5;x+=1){wbar(x,.1,back,x,4.5,back,.028,C.mark,.12);wbar(x,4.49,z,x,4.49,back,.024,C.mark,.12);}
  for(let y=.5;y<4.5;y+=.62){wbar(-5.4,y,back,5.4,y,back,.028,C.mark,.1);for(let x of [-5.4,5.4])wbar(x,y,z,x,y,back,.025,C.mark,.08);}
  for(let zz=25.3;zz<=28.5;zz+=.65){for(let x of [-5.4,5.4])wbar(x,.1,side*zz,x,4.49,side*zz,.025,C.mark,.1);}
  wbox(0,.055,side*25.1,10.4,.01,.2,col,.7);
  wbox(0,4.48,side*26.85,10.8,.16,3.4,C.metal,.1);
  wbox(0,2.25,side*29.05,11,.15,4.5,col,.15);
  wbox(0,.25,side*29.2,9,.24,.19,col,.5);
  // Stylised score towers around end walls
  for(let xx of [-13,13]){wbox(xx,5.1,side*27,.75,10,.75,C.metal);wbox(xx,10.2,side*27,1.1,.28,1.1,col,.7);}
  wbox(0,9.25,side*30,10.2,2.8,.55,C.metal);
  wbox(0,9.25,side*29.7,8.6,2.0,.06,col,.22);
 }
 for(let xx of [-26,26])for(let zz of [-34,34]){
  wbox(xx,6.8,zz,.55,13,.55,C.metal);wbox(xx,13.3,zz,4,.36,2.8,C.white,.75);
 }
 for(let i=0;i<5;i++){const x=-13.5+i*6.7;wbox(x,8.8,-36,4.5,.2,2.3,C.rail);wbox(x,8.8,36,4.5,.2,2.3,C.rail);}
 for(const sign of [-1,1])for(let zi=-3;zi<=3;zi++){wbox(sign*28,11.1,zi*8,2.2,.12,3,zi%2?C.blue:C.orange,.2);}
 // Centre arcs of spectators and big steel supports.
 for(let i=0;i<34;i++){
  const zz=-34+i*2.06;
  for(let x of [-30,-27,27,30]){
   const hue=(i%5===0)?C.orange:(i%3===0?C.blue:C.rail);
   wbox(x,9.2+(Math.abs(x)===30?1.2:0),zz,1.45,.48,.45,hue,.2);
  }
 }
}
buildWorld();
const padPlaces=[[-12,-17,100],[12,17,100],[-12,17,100],[12,-17,100],[-8,0,28],[8,0,28],[0,-12,28],[0,12,28],[-12,-6,28],[12,6,28],[-12,6,28],[12,-6,28]];
const padStatic=padPlaces.map(([x,z,qty])=>({x,z,qty}));
function renderPads(pads){for(let i=0;i<padStatic.length;i++){const p=padStatic[i],on=(!pads||pads[i]!==0),r=p.qty===100?1.18:.76;draw('ring',M(p.x,.081,p.z,r,1,r),on?C.boost:C.metal,on?.72:.1);if(on){draw('cyl',M(p.x,.12,p.z,r*.57,.09,r*.57),C.boost,.8);const bob=Math.sin(tGlobal*3+i)*.09;draw('sphere',M(p.x,.46+bob,p.z,p.qty===100?.43:.25,p.qty===100?.43:.25,p.qty===100?.43:.25),C.orangeLite,.65);}else draw('cyl',M(p.x,.08,p.z,r*.4,.05,r*.4),C.metal);}}
function drawBall(b){
 draw('sphere',M(b.x,.037,b.z,1.18,.015,1.18),C.dark);
 draw('ring',M(b.x,.061,b.z,1.16,1,1.16),C.blue,.34);
 let m=mul(translation(b.x,b.y,b.z),mul(rotX(b.rx||0),rotZ(b.rz||0)));
 draw('sphere',mul(m,scaling(1.02,1.02,1.02)),C.white,.15,1);
 draw('sphere',M(b.x,b.y,b.z,.13,.13,.13),C.blue,.5);
}
function renderCar(c,i){
 const team=i===0?C.blue:C.orange,trim=i===0?C.blueLite:C.orangeLite;
 const x=c.x,y=c.y,z=c.z;
 draw('sphere',M(x,.06,z,2,.07,2.6),C.dark);
 const parent=mul(translation(x,y,z),mul(rotY(-(c.yaw||0)),mul(rotX(c.pitch||0),rotZ(c.roll||0))));
 const part=(shape,px,py,pz,sx,sy,sz,col,glow=0,yaw=0,pitch=0,roll=0)=>draw(shape,mul(parent,M(px,py,pz,sx,sy,sz,yaw,pitch,roll)),col,glow);
 part('box',0,0,0,2.06,.54,3.65,team,.08);
 part('box',0,.21,-.78,1.85,.48,1.65,team,.12);
 part('box',0,.48,.30,1.60,.66,1.65,C.glass,.09);
 part('box',0,.85,.34,1.36,.12,1.23,trim,.18);
 part('box',0,.26,1.28,1.87,.37,.86,C.roof);
 part('box',0,.37,-1.78,1.68,.20,.23,C.roof);
 part('box',0,-.16,-1.9,1.8,.19,.27,C.dark);
 part('box',0,-.30,1.94,1.83,.24,.21,C.metal);
 part('box',0,.6,1.87,2.1,.12,.42,team,.55);
 for(const xx of [-.87,.87]){
  part('box',xx,.26,-1.82,.30,.16,.1,C.white,.75);
  part('box',xx,.26,1.91,.29,.16,.08,C.orange,.7);
  for(const zz of [-1.2,1.18]){
   part('cyl',xx*1.16,-.31,zz,.66,.37,.66,C.tire,0,0,0,PI/2);
   part('cyl',xx*1.17,-.31,zz,.28,.39,.28,C.roof,.22,0,0,PI/2);
  }
  part('box',xx*1.04,.32,.15,.10,.16,2.4,trim,.35);
 }
 part('box',0,-.04,-1.96,1.1,.09,.12,trim,.35);
 if(c.boostOn){const flick=.8+Math.random()*.4;for(const xx of [-.56,.56]){
   part('sphere',xx,-.10,2.16,.22,.2,.36,C.orangeLite,.8);
   part('sphere',xx,-.10,2.4+.45*flick,.14,.13,.75*flick,C.orange,.95);
 }}else{for(const xx of [-.52,.52])part('box',xx,-.07,1.91,.25,.17,.1,C.orange,.25);}
}
const demoCars=[{x:-5,y:.66,z:10,yaw:.24,pitch:0,roll:0,boostOn:false},{x:5,y:.66,z:-10,yaw:PI+.35,pitch:0,roll:0,boostOn:false}];
let socket=null,player=-1,room='',joined=false,match=null,lastStateAt=0,lastSeq=0,lastGoals='0:0',lastPhase='waiting';
let clockPing=0,connected=false,ballCam=false,deviceMode=false;
let desired={throttle:0,steer:0,boost:false,jump:false};
const keys=new Set(),touch={throttle:0,steer:0,boost:false,jump:false,engaged:false};
let cameraEye=[0,20,40],cameraTarget=[0,0,0],renderCars=demoCars.map(x=>({...x})),ballDisplay={x:0,y:1.02,z:0,vx:0,vy:0,vz:0,rx:0,rz:0};
let toastTimer;
function toast(s){const el=$('toast');el.textContent=s;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3400);}
function network(ok){connected=ok;$('networkDot').classList.toggle('offline',!ok);$('netText').textContent=ok?'ONLINE':'DISCONNECTED';if(!ok)$('latency').textContent='— ms';}
function showLobby(){joined=false;$('menu').classList.remove('hidden');$('inGame').classList.add('hidden');$('scoreboard').classList.add('hidden');$('menuHome').classList.toggle('hidden',!!room);$('menuLobby').classList.toggle('hidden',!room);if(room){$('roomCode').textContent=room;$('lobbyStatus').textContent='Waiting for player 2 to join...';}}
function showGame(){joined=true;$('menu').classList.add('hidden');$('inGame').classList.remove('hidden');$('scoreboard').classList.remove('hidden');$('floatingMessage').classList.remove('hidden');$('leftLabel').innerHTML='YOU <span id="teamColor">'+(player===0?'BLUE':'ORANGE')+'</span>';$('teamColor').style.color=player===0?'#5ddcff':'#ffb567';$('hudCode').textContent=room;toast('MATCH FOUND — LET’S GO!');}
function doSend(data){if(socket&&socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify(data));else toast('Not connected. Check your connection.');}
function connect(){const protocol=location.protocol==='https:'?'wss:':'ws:';socket=new WebSocket(protocol+'//'+location.host+'/ws');socket.addEventListener('open',()=>{network(true);clockPing=performance.now();doSend({type:'ping',sent:clockPing});const query=new URLSearchParams(location.search).get('room');if(query){$('codeInput').value=query.toUpperCase();doSend({type:'join',code:query.toUpperCase()});}});
 socket.addEventListener('message',evt=>{let msg;try{msg=JSON.parse(evt.data);}catch{return;}switch(msg.type){
 case 'room':room=msg.code;player=msg.player;showLobby();break;
 case 'peer_joined':showGame();break;
 case 'peer_left':joined=false;showLobby();toast('Opponent left the match. Share your code for a rematch.');break;
 case 'left':room='';player=-1;match=null;history.replaceState(null,'',location.pathname);showLobby();break;
 case 'state':match=msg;lastStateAt=performance.now();lastSeq=msg.seq;updateHud(msg);break;
 case 'pong':$('latency').textContent=Math.round(performance.now()-Number(msg.sent||performance.now()))+' ms';break;
 case 'error':toast(msg.message||'Something went wrong.');break;
 }});
 socket.addEventListener('close',()=>{network(false);joined=false;room='';player=-1;match=null;showLobby();toast('Disconnected from the game server. Reload to reconnect.');});socket.addEventListener('error',()=>network(false));}
function startSound(freq=440,dur=.08,type='sine',volume=.03){try{if(!window.AudioContext&&!window.webkitAudioContext)return;if(!startSound.ctx)startSound.ctx=new (window.AudioContext||window.webkitAudioContext)();const ctx=startSound.ctx;if(ctx.state==='suspended')ctx.resume();const osc=ctx.createOscillator(),gain=ctx.createGain();osc.type=type;osc.frequency.setValueAtTime(freq,ctx.currentTime);osc.frequency.exponentialRampToValueAtTime(Math.max(55,freq*.52),ctx.currentTime+dur);gain.gain.setValueAtTime(volume,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+dur);osc.connect(gain).connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+dur);}catch(e){}}
function updateHud(s){
 $('blueScore').textContent=s.scores[0];$('orangeScore').textContent=s.scores[1];const sec=Math.ceil(s.remaining);$('gameClock').textContent=Math.floor(sec/60)+':'+String(sec%60).padStart(2,'0');
 $('matchStatus').textContent=s.phase==='countdown'?'KICKOFF':s.phase==='playing'?'1V1 ONLINE MATCH':s.phase==='goal'?'GOAL!':s.phase==='finished'?'FULL TIME':'WAITING';
 let msg='',theme='';if(s.phase==='countdown'){const n=Math.ceil(s.phaseTimer);msg=n>0?String(n):'GO!';}else if(s.phase==='goal'){msg=s.celebration;theme=s.celebration.includes('ORANGE')?'orange':'blue';}else if(s.phase==='finished'){msg=s.celebration;theme=s.winner===1?'orange':'blue';}
 const el=$('floatingMessage');el.textContent=msg;el.className=msg?theme:'hidden';
 if(s.phase==='goal'&&lastPhase!=='goal')startSound(740,.55,'sawtooth',.035);
 if(s.phase==='playing'&&lastPhase==='countdown')startSound(560,.18,'triangle',.035);
 lastPhase=s.phase;
 lastGoals=s.scores.join(':');
}
function updateInput(){let throttle=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);let steer=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0);if(touch.engaged){throttle=touch.throttle;steer=touch.steer;}
 desired={type:'input',throttle,steer,boost:keys.has('ShiftLeft')||keys.has('ShiftRight')||touch.boost,jump:keys.has('Space')||touch.jump,handbrake:keys.has('ControlLeft')||keys.has('ControlRight'),airRoll:(keys.has('KeyE')?1:0)-(keys.has('KeyQ')?1:0)};}
const playingKeys=new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowRight','ArrowDown','ShiftLeft','ShiftRight','Space','KeyC','KeyQ','KeyE','ControlLeft','ControlRight']);
window.addEventListener('keydown',e=>{if(document.activeElement===$('codeInput'))return;if(playingKeys.has(e.code))e.preventDefault();if(e.code==='KeyC'&&!e.repeat){ballCam=!ballCam;$('cameraBadge').textContent=(ballCam?'BALL CAM':'CAR CAM')+' · C TO TOGGLE';}keys.add(e.code);if(e.code==='Space'&&!e.repeat)startSound(170,.08,'square',.008);});
window.addEventListener('keyup',e=>keys.delete(e.code));
window.addEventListener('blur',()=>{keys.clear();touch.throttle=0;touch.steer=0;touch.boost=false;touch.jump=false;touch.engaged=false;});
$('createBtn').onclick=()=>{if(!connected){toast('Cannot reach server. Reload the page.');return;}doSend({type:'create'});startSound(540,.12,'triangle',.02);};
$('joinBtn').onclick=joinRoom;$('codeInput').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();joinRoom();}};
$('codeInput').oninput=()=>{$('codeInput').value=$('codeInput').value.toUpperCase().replace(/[^A-Z0-9]/g,'');};
function joinRoom(){const code=$('codeInput').value.trim().toUpperCase();if(code.length!==5){toast('Enter the 5-character room code.');return;}doSend({type:'join',code});}
$('leaveBtn').onclick=()=>{doSend({type:'leave'});room='';joined=false;match=null;history.replaceState(null,'',location.pathname);showLobby();};
function inviteUrl(){const u=new URL(location.href);u.searchParams.set('room',room);return u.href;}
async function copy(what){const value=what==='code'?room:inviteUrl();if(!value)return;try{await navigator.clipboard.writeText(value);toast(what==='code'?'Room code copied!':'Invite link copied!');}catch{prompt('Copy this and send it to your friend:',value);}}
$('copyCode').onclick=()=>copy('code');$('inviteBtn').onclick=()=>copy('url');$('hudCopy').onclick=()=>copy('url');
$('cameraBadge').onclick=()=>{ballCam=!ballCam;$('cameraBadge').textContent=(ballCam?'BALL CAM':'CAR CAM')+' · TAP TO TOGGLE';};
// Mobile two-axis left joystick + thumb-sized right buttons. No external touch library.
const joy=$('joystick'),knob=$('joyKnob');let joyPointer=null;
joy.addEventListener('pointerdown',e=>{e.preventDefault();joyPointer=e.pointerId;joy.setPointerCapture(e.pointerId);touch.engaged=true;moveJoy(e);});
joy.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)moveJoy(e);});
function moveJoy(e){const r=joy.getBoundingClientRect(),x=(e.clientX-(r.left+r.width/2))/(r.width*.5),y=(e.clientY-(r.top+r.height/2))/(r.height*.5),m=Math.max(1,Math.hypot(x,y)),sx=x/m,sy=y/m;knob.style.left=(50+sx*31)+'%';knob.style.top=(50+sy*31)+'%';touch.steer=Math.abs(sx)<.11?0:clamp(sx*1.3,-1,1);touch.throttle=Math.abs(sy)<.10?0:clamp(-sy*1.45,-1,1);}
function releaseJoy(e){if(joyPointer!==e.pointerId)return;joyPointer=null;touch.engaged=false;touch.throttle=touch.steer=0;knob.style.left='50%';knob.style.top='50%';}
joy.addEventListener('pointerup',releaseJoy);joy.addEventListener('pointercancel',releaseJoy);joy.addEventListener('lostpointercapture',()=>{joyPointer=null;touch.engaged=false;touch.throttle=touch.steer=0;});
for(const [id,action]of [['boostTouch','boost'],['jumpTouch','jump']]){const btn=$(id);btn.addEventListener('pointerdown',e=>{e.preventDefault();btn.setPointerCapture(e.pointerId);touch[action]=true;btn.classList.add('active');if(action==='jump')startSound(200,.08,'square',.008);});for(const ev of ['pointerup','pointercancel','lostpointercapture'])btn.addEventListener(ev,()=>{touch[action]=false;btn.classList.remove('active');});}
let lastInput=0,lastPing=0,lastFrame=performance.now();
function frame(now){requestAnimationFrame(frame);const dt=clamp((now-lastFrame)/1000,0,.05);lastFrame=now;tGlobal+=dt;resize();updateInput();
 if(joined&&now-lastInput>33){doSend(desired);lastInput=now;}
 if(connected&&now-lastPing>6500){lastPing=now;doSend({type:'ping',sent:performance.now()});}
 if(match){const lag=clamp((now-lastStateAt)/1000,0,.065);for(let i=0;i<2;i++){
   const raw=match.cars[i],dst=renderCars[i];if(!raw)continue;
   for(const k of ['x','y','z']){let val=raw[k]+(raw['v'+k]||0)*lag;dst[k]=lerp(dst[k]??val,val,clamp(dt*17,0,1));}
   let delta=((raw.yaw-(dst.yaw??raw.yaw)+PI)%TAU+TAU)%TAU-PI;dst.yaw=(dst.yaw??raw.yaw)+delta*clamp(dt*18,0,1);
   dst.pitch=lerp(dst.pitch||0,raw.pitch||0,clamp(dt*17,0,1));dst.roll=lerp(dst.roll||0,raw.roll||0,clamp(dt*17,0,1));dst.boostOn=raw.boostOn;
 }
 for(const k of ['x','y','z','rx','rz']){const val=(match.ball[k]||0)+(k==='x'||k==='y'||k==='z'?(match.ball['v'+k]||0)*lag:0);ballDisplay[k]=lerp(ballDisplay[k]??val,val,clamp(dt*19,0,1));}
 }else{
   ballDisplay.y=1.1+Math.sin(tGlobal*2.1)*.23;ballDisplay.rx=tGlobal*.25;ballDisplay.rz=tGlobal*.38;
   renderCars[0].yaw=.24+Math.sin(tGlobal*.4)*.11;
   renderCars[1].yaw=PI+.35+Math.sin(tGlobal*.45)*.11;
 }
 let eye,look;
 if(joined&&player!==-1){const c=renderCars[player],yaw=c.yaw||0;const fx=Math.sin(yaw),fz=-Math.cos(yaw);
   const behind=ballCam?9:10.6;
   eye=[c.x-fx*behind,c.y+5.05,c.z-fz*behind];
   if(ballCam){const v=[ballDisplay.x-c.x,ballDisplay.y-c.y,ballDisplay.z-c.z];const L=Math.hypot(v[0],v[2])||1;look=[c.x+v[0]*.44,c.y+1.35+Math.max(0,v[1]*.26),c.z+v[2]*.44];if(L>17)look=[ballDisplay.x*.65+c.x*.35,ballDisplay.y*.44+1,ballDisplay.z*.65+c.z*.35];}
   else look=[c.x+fx*6.5,c.y+1.55,c.z+fz*6.5];
   if(match&&match.phase==='goal'){eye=[ballDisplay.x+11,11,ballDisplay.z+13];look=[ballDisplay.x,1,ballDisplay.z];}
 }else{eye=[Math.cos(tGlobal*.13)*33,18+Math.sin(tGlobal*.14)*3,Math.sin(tGlobal*.13)*42];look=[0,0,0];}
 const fac=1-Math.exp(-dt*(joined?7.5:1.6));cameraEye=mix(cameraEye,eye,fac);cameraTarget=mix(cameraTarget,look,fac);
 gl.viewport(0,0,resizeW,resizeH);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 gl.useProgram(program);gl.uniformMatrix4fv(loc.view,false,new Float32Array(lookAt(cameraEye,cameraTarget)));gl.uniformMatrix4fv(loc.proj,false,new Float32Array(perspective((joined?65:56)*PI/180,resizeW/resizeH,.2,270)));
 for(const [shape,m,c,e,mode]of WORLD)draw(shape,m,c,e,mode);
 renderPads(match?.pads);
 for(let i=0;i<2;i++)renderCar(renderCars[i],i);
 drawBall(ballDisplay);
 if(joined&&match&&player!==-1){const c=match.cars[player];$('boostCount').textContent=Math.round(c.boost);$('boostFill').style.width=clamp(c.boost,0,100)+'%';$('speedNum').textContent=String(Math.round(Math.hypot(c.vx,c.vz)*6.5)).padStart(3,'0');}
}
try{connect();}catch(e){toast('WebSocket connection could not be started.');}
requestAnimationFrame(frame);
})();
