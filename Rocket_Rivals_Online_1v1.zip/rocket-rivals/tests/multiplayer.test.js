const test=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const net=require('node:net');
const {once}=require('node:events');

function collector(ws){
 const events=[],waiters=[];
 ws.addEventListener('message',ev=>{
  const msg=JSON.parse(ev.data);
  const ix=waiters.findIndex(w=>w.filter(msg));
  if(ix!==-1){const w=waiters.splice(ix,1)[0];clearTimeout(w.timer);w.resolve(msg);}else events.push(msg);
 });
 return function next(filter=()=>true,timeout=6000){
  const ix=events.findIndex(filter);
  if(ix!==-1)return Promise.resolve(events.splice(ix,1)[0]);
  return new Promise((resolve,reject)=>{const w={filter,resolve,timer:null};w.timer=setTimeout(()=>{waiters.splice(waiters.indexOf(w),1);reject(new Error('Timed out waiting for game event'));},timeout);waiters.push(w);});
 };
}
async function availablePort(){
 const srv=net.createServer();srv.listen(0,'127.0.0.1');await once(srv,'listening');const port=srv.address().port;await new Promise(r=>srv.close(r));return port;
}
test('two WebSocket players can create a room, join by code, play, and detect disconnect', {timeout:18000},async()=>{
 const port=await availablePort();
 const proc=spawn(process.execPath,['server/index.js'],{cwd:require('node:path').resolve(__dirname,'..'),env:{...process.env,PORT:String(port)}});
 const logs=[];proc.stderr.on('data',d=>logs.push(String(d)));
 let a,b;
 try{
  for(let i=0;i<60;i++){
   try{const r=await fetch(`http://127.0.0.1:${port}/health`);if(r.ok)break;}
   catch{}await new Promise(r=>setTimeout(r,65));
  }
  const response=await fetch(`http://127.0.0.1:${port}/`);
  assert.equal(response.status,200);
  assert.match(await response.text(),/ROCKET RIVALS/);
  a=new WebSocket(`ws://127.0.0.1:${port}/ws`);await once(a,'open');const aNext=collector(a);
  a.send(JSON.stringify({type:'create'}));
  const room=await aNext(m=>m.type==='room');
  assert.match(room.code,/^[A-HJ-NP-Z2-9]{5}$/);assert.equal(room.player,0);
  b=new WebSocket(`ws://127.0.0.1:${port}/ws`);await once(b,'open');const bNext=collector(b);
  b.send(JSON.stringify({type:'join',code:room.code}));
  const joined=await bNext(m=>m.type==='room');assert.equal(joined.player,1);
  await aNext(m=>m.type==='peer_joined');
  let playing=false;
  for(let i=0;i<180;i++){
   if(i%10===0){a.send(JSON.stringify({type:'input',throttle:1,boost:true}));}
   const event=await aNext(m=>m.type==='state');
   if(event.phase==='playing'&&event.cars[0].boost<69){
     assert.ok(event.ball.y>=1.02);
     assert.ok(event.cars[0].z<13);
     playing=true;break;
   }
  }
  assert.ok(playing,'Both clients received live match state and car controls affected physics');
  b.close();
  const left=await aNext(m=>m.type==='peer_left');assert.equal(left.type,'peer_left');
 }finally{if(a)a.close();if(b)b.close();proc.kill('SIGTERM');}
 assert.deepEqual(logs,[]);
});
