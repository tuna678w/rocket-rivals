'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {Match,BALL_R,GOAL_W,GOAL_H,WIDTH,LENGTH}=require('../server/physics');
const run=(game,n)=>{for(let i=0;i<n;i++)game.step(1/60,2);};

test('match starts with kickoff and transitions into playing',()=>{
  const game=new Match();game.start();
  assert.equal(game.phase,'countdown');
  run(game,200);
  assert.equal(game.phase,'playing');
  assert.deepEqual(game.scores,[0,0]);
  assert.ok(game.remaining<=180 && game.remaining>179.9);
});
test('car accelerates, steers, boosts and jump/dodges',()=>{
  const game=new Match();game.start();run(game,205);
  const car=game.cars[0];const originalZ=car.z;
  game.setInput(0,{throttle:1,boost:true,steer:0,jump:false});run(game,16);
  assert.ok(car.z<originalZ-1,'drives forward');
  assert.ok(car.boost<70,'boost is consumed');
  const previousYaw=car.yaw;
  game.setInput(0,{throttle:1,boost:false,steer:1,jump:true});run(game,1);
  assert.equal(car.grounded,false);assert.equal(car.jumps,1);
  assert.ok(car.yaw>previousYaw);
  game.setInput(0,{throttle:1,boost:false,steer:0,jump:false});run(game,2);
  game.setInput(0,{throttle:1,boost:false,steer:0,jump:true});run(game,1);
  assert.equal(car.jumps,2);
  assert.ok(car.dodge>0);
});
test('ball bounces off side walls and stays above the pitch',()=>{
 const game=new Match();game.start();game.phase='playing';
 Object.assign(game.ball,{x:WIDTH/2-BALL_R-.02,y:BALL_R,z:0,vx:9,vy:-4,vz:0});
 run(game,3);
 assert.ok(game.ball.x<=WIDTH/2-BALL_R+1e-7);
 assert.ok(game.ball.vx<0);
 assert.ok(game.ball.y>=BALL_R);
});
test('ball crossing the orange goal awards blue a point',()=>{
 const game=new Match();game.start();game.phase='playing';
 Object.assign(game.ball,{x:0,y:BALL_R+.01,z:-LENGTH/2+.7,vx:0,vy:0,vz:-19});
 run(game,6);
 assert.equal(game.phase,'goal');
 assert.deepEqual(game.scores,[1,0]);
 assert.equal(game.celebration,'BLUE SCORES!');
 run(game,180);
 assert.equal(game.phase,'countdown');
 assert.deepEqual(game.scores,[1,0]);
});
test('shots beyond the left goalpost bounce without scoring',()=>{
 const game=new Match();game.start();game.phase='playing';
 Object.assign(game.ball,{x:GOAL_W/2+BALL_R+2,y:BALL_R+.01,z:-LENGTH/2+.75,vx:0,vy:0,vz:-16});
 run(game,12);
 assert.deepEqual(game.scores,[0,0]);
 assert.ok(game.ball.vz>0);
});
test('boost pickup refills boost then respawns after cooldown',()=>{
 const game=new Match();game.start();game.phase='playing';
 const c=game.cars[0];
 Object.assign(c,{x:-8,z:0,vx:0,vz:0,boost:22});
 game.pickupBoost(c);
 assert.equal(c.boost,50);
 assert.ok(game.pads[4].respawn>0);
});
test('no invalid numbers propagate into physics after hostile input',()=>{
 const game=new Match();game.start();game.phase='playing';
 game.setInput(0,{throttle:'not a number',steer:Infinity,boost:'true',jump:3});
 run(game,70);
 for(const c of game.cars)for(const key of ['x','y','z','vx','vy','vz','yaw','boost'])assert.ok(Number.isFinite(c[key]),`${key} finite`);
});
