'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const http=require('node:http');
const {once}=require('node:events');
const net=require('node:net');
function freePort(){return new Promise((res,rej)=>{const sock=net.createServer();sock.listen(0,'127.0.0.1',()=>{const port=sock.address().port;sock.close(()=>res(port));});sock.on('error',rej);});}
async function waitHealth(port){for(let i=0;i<80;i++){try{const result=await new Promise((resolve,reject)=>{http.get(`http://127.0.0.1:${port}/health`,resp=>{let s='';resp.on('data',x=>s+=x);resp.on('end',()=>resolve(JSON.parse(s)));}).on('error',reject);});if(result.ok)return;}catch{}await new Promise(r=>setTimeout(r,50));}throw Error('server failed to start');}
async function connect(port){const ws=new WebSocket(`ws://127.0.0.1:${port}/ws`);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});const queue=[],waiters=[];
 ws.addEventListener('message',evt=>{const msg=JSON.parse(evt.data);const idx=waiters.findIndex(w=>w.type===msg.type);if(idx>=0){const w=waiters.splice(idx,1)[0];clearTimeout(w.timer);w.resolve(msg);}else queue.push(msg);});
 return {ws,send:m=>ws.send(JSON.stringify(m)),wait(type,timeout=3000){const idx=queue.findIndex(m=>m.type===type);if(idx>=0)return Promise.resolve(queue.splice(idx,1)[0]);return new Promise((resolve,reject)=>{const w={type,resolve,timer:setTimeout(()=>{const i=waiters.indexOf(w);if(i>=0)waiters.splice(i,1);reject(new Error(`timed out waiting for ${type}`));},timeout)};waiters.push(w);});}};
}
test('HTTP and real WebSocket clients can create and join same private match',async()=>{
 const port=await freePort();const server=spawn(process.execPath,['server/index.js'],{cwd:require('node:path').resolve(__dirname,'..'),env:{...process.env,PORT:String(port)},stdio:'ignore'});
 let a,b;
 try{
  await waitHealth(port);a=await connect(port);b=await connect(port);
  a.send({type:'create'});const created=await a.wait('room');
  assert.match(created.code,/^[A-HJ-NP-Z2-9]{5}$/);assert.equal(created.player,0);
  b.send({type:'join',code:'ZZZZZ'});assert.match((await b.wait('error')).message,/not found/i);
  b.send({type:'join',code:created.code});const joined=await b.wait('room');assert.equal(joined.player,1);
  await Promise.all([a.wait('peer_joined'),b.wait('peer_joined')]);
  let snap=await b.wait('state');assert.equal(snap.phase,'countdown');assert.deepEqual(snap.scores,[0,0]);
  a.send({type:'input',throttle:1,boost:true,steer:0,jump:false});
  b.send({type:'input',throttle:1,boost:false,steer:0,jump:false});
  await new Promise(r=>setTimeout(r,160));
  snap=await a.wait('state');for(let i=0;i<15 && snap.seq===0;i++)for(let k=0;k<12;k++){snap=await a.wait('state');if(snap.seq>0)break;}assert.equal(snap.cars.length,2);assert.ok(snap.seq>0);
  b.ws.close();const left=await a.wait('peer_left');assert.equal(left.type,'peer_left');
 } finally {if(a)a.ws.close();if(b)b.ws.close();server.kill('SIGTERM');}
});
