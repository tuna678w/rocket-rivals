const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');

test('entire WebGL game client initializes and renders frames without runtime errors',()=>{
  const noop=()=>{};
  const fakeGL=new Proxy({
    VERTEX_SHADER:35633,FRAGMENT_SHADER:35632,COMPILE_STATUS:35713,LINK_STATUS:35714,
    ARRAY_BUFFER:34962,ELEMENT_ARRAY_BUFFER:34963,STATIC_DRAW:35044,
    FLOAT:5126,TRIANGLES:4,UNSIGNED_SHORT:5123,DEPTH_TEST:2929,CULL_FACE:2884,
    COLOR_BUFFER_BIT:16384,DEPTH_BUFFER_BIT:256,DEPTH_MASK:2930,
    createShader:()=>({}),getShaderParameter:()=>true,createProgram:()=>({}),getProgramParameter:()=>true,
    createBuffer:()=>({}),getAttribLocation:()=>1,getUniformLocation:()=>({})
  },{get:(o,k)=>k in o?o[k]:noop});
  const elements=new Map();
  function element(id){
    if(!elements.has(id))elements.set(id,{
      textContent:'',value:'',innerHTML:'',style:{},classList:{add:noop,remove:noop,toggle:noop,contains:()=>false},
      addEventListener:noop,setPointerCapture:noop,getBoundingClientRect:()=>({left:0,top:0,width:120,height:120}),
      getContext:()=>fakeGL,clientWidth:1200,clientHeight:800,
    });
    return elements.get(id);
  }
  const calls=[];
  const client={
    document:{getElementById:element,activeElement:element('notFocused')},
    window:{devicePixelRatio:1,addEventListener:noop,AudioContext:null},
    location:{protocol:'http:',host:'localhost:3000',pathname:'/',href:'http://localhost:3000/'},
    history:{replaceState:noop},navigator:{clipboard:{writeText:async()=>{}}},
    WebSocket:class{static OPEN=1;constructor(){this.readyState=1;}addEventListener(){}send(){}},
    performance:{now:()=>1000},requestAnimationFrame:(cb)=>calls.push(cb),
    URL,URLSearchParams,Math,Float32Array,Uint16Array,Uint8Array,
    setTimeout:()=>1,clearTimeout:noop,prompt:noop,
  };
  client.window.window=client.window;
  const code=fs.readFileSync(path.join(__dirname,'../public/game.js'),'utf8');
  vm.runInNewContext(code,client,{filename:'game.js',timeout:6000});
  assert.equal(calls.length,1);
  for(let i=1;i<=3;i++){
    const cb=calls.pop();cb(1000+i*16.667);
    assert.equal(calls.length,1);
  }
});
