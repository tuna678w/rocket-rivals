'use strict';
const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {Match}=require('./physics');

const PORT=Number(process.env.PORT)||3000;
const STATIC=path.join(__dirname,'..','public');
const rooms=new Map();
const connections=new Set();
const MAX_ROOMS=250;
const ROOM_ALPHABET='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function roomCode(){
  for(let tries=0;tries<1000;tries++){
    let str='';for(let i=0;i<5;i++)str+=ROOM_ALPHABET[crypto.randomInt(ROOM_ALPHABET.length)];
    if(!rooms.has(str))return str;
  }
  throw new Error('Too many rooms');
}
const mime={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.webmanifest':'application/manifest+json'};
const server=http.createServer((req,res)=>{
  const rawPath=(req.url||'/').split('?')[0];
  if(rawPath==='/health'){
    res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({ok:true,rooms:rooms.size}));return;
  }
  let pathname;try{pathname=decodeURIComponent(rawPath)}catch(e){res.writeHead(400);res.end();return;}
  const requested=pathname==='/'?'/index.html':pathname;
  const full=path.resolve(STATIC,'.'+requested);
  if(!full.startsWith(STATIC+path.sep)){res.writeHead(403);res.end();return;}
  fs.stat(full,(err,stat)=>{
    if(err||!stat.isFile()){res.writeHead(404,{'Content-Type':'text/plain'});res.end('Not found');return;}
    res.writeHead(200,{'Content-Type':mime[path.extname(full)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    fs.createReadStream(full).pipe(res);
  });
});
class Peer{
  constructor(socket){
    this.socket=socket;this.buffer=Buffer.alloc(0);this.room=null;this.slot=-1;
    this.closed=false;this.lastSeen=Date.now();this.lastInput=0;
    connections.add(this);
    socket.on('data',data=>this.receive(data));
    socket.on('error',()=>this.close());
    socket.on('end',()=>this.close());
    socket.on('close',()=>this.close());
    socket.setNoDelay(true);
  }
  send(data){
    if(this.closed||!this.socket.writable)return;
    const payload=Buffer.from(JSON.stringify(data));
    let header;
    if(payload.length<126){header=Buffer.from([0x81,payload.length]);}
    else if(payload.length<65536){header=Buffer.alloc(4);header[0]=0x81;header[1]=126;header.writeUInt16BE(payload.length,2);}
    else return;
    try{this.socket.write(Buffer.concat([header,payload]));}catch(e){this.close();}
  }
  ping(){if(!this.closed && this.socket.writable)this.socket.write(Buffer.from([0x89,0]));}
  receive(chunk){
    if(this.closed)return;
    this.lastSeen=Date.now();
    if(this.buffer.length+chunk.length>65536){this.close();return;}
    this.buffer=Buffer.concat([this.buffer,chunk]);
    while(this.buffer.length>=2){
      const b0=this.buffer[0],b1=this.buffer[1];
      const opcode=b0&15,masked=(b1&128)!==0;
      let len=b1&127,head=2;
      if(len===126){if(this.buffer.length<4)return;len=this.buffer.readUInt16BE(2);head=4;}
      if(len===127 || len>8192||!masked || (b0&0x70)!==0){this.close();return;}
      if(this.buffer.length<head+4+len)return;
      const mask=this.buffer.subarray(head,head+4);
      const payload=Buffer.from(this.buffer.subarray(head+4,head+4+len));
      for(let i=0;i<len;i++)payload[i]^=mask[i%4];
      this.buffer=this.buffer.subarray(head+4+len);
      if(opcode===8){this.close();return;}
      if(opcode===9){this.socket.write(Buffer.from([0x8a,0]));continue;}
      if(opcode===10)continue;
      if(opcode!==1 || (b0&0x80)===0){this.close();return;}
      let obj;try{obj=JSON.parse(payload.toString('utf8'));}catch(e){continue;}
      this.handle(obj);
    }
  }
  leave(){
    const room=this.room;
    if(!room)return;
    room.players[this.slot]=null;
    this.room=null;this.slot=-1;
    const other=room.players.find(Boolean);
    if(other){
      room.game.phase='waiting';
      other.send({type:'peer_left'});
      room.lastActive=Date.now();
    }else rooms.delete(room.code);
  }
  close(){
    if(this.closed)return;
    this.closed=true;
    this.leave();
    connections.delete(this);
    if(!this.socket.destroyed)this.socket.destroy();
  }
  handle(msg){
    if(!msg||typeof msg!=='object')return;
    if(msg.type==='create'){
      this.leave();
      if(rooms.size>=MAX_ROOMS){this.send({type:'error',message:'All rooms are busy. Please try again later.'});return;}
      const code=roomCode();
      const room={code,players:[this,null],game:new Match(),lastActive:Date.now()};
      rooms.set(code,room);
      this.room=room;this.slot=0;
      this.send({type:'room',code,player:0});
      this.send(room.game.snapshot());
    }else if(msg.type==='join'){
      const code=String(msg.code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);
      const room=rooms.get(code);
      if(!room){this.send({type:'error',message:'Room not found. Check the code.'});return;}
      if(room.players.every(Boolean) && !room.players.includes(this)){
        this.send({type:'error',message:'Room is full (2 players max).'});return;
      }
      if(this.room===room){this.send({type:'room',code,player:this.slot});return;}
      this.leave();
      const slot=room.players[0]?1:0;
      room.players[slot]=this;this.room=room;this.slot=slot;
      room.lastActive=Date.now();
      this.send({type:'room',code,player:slot});
      room.players.forEach(peer=>peer&&peer.send({type:'peer_joined'}));
      room.game.start();
      room.players.forEach(peer=>peer&&peer.send(room.game.snapshot()));
    }else if(msg.type==='input'&&this.room){
      const now=Date.now();
      if(now-this.lastInput<8)return;
      this.lastInput=now;
      this.room.game.setInput(this.slot,msg);
      this.room.lastActive=now;
    }else if(msg.type==='ping'){
      this.send({type:'pong',sent:msg.sent});
    }else if(msg.type==='leave'){
      this.leave();this.send({type:'left'});
    }
  }
}
server.on('upgrade',(req,socket,head)=>{
  const key=req.headers['sec-websocket-key'];
  if(req.url?.split('?')[0]!=='/ws'||req.headers.upgrade?.toLowerCase()!=='websocket'||!key||typeof key!=='string'){
    socket.destroy();return;
  }
  const accept=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+accept+'\r\n\r\n');
  const peer=new Peer(socket);
  if(head.length)peer.receive(head);
});
let lastTick=process.hrtime.bigint(),accumulator=0,steps=0;
const tick=setInterval(()=>{
  const now=process.hrtime.bigint();
  let dt=Number(now-lastTick)/1e9;lastTick=now;
  accumulator+=Math.min(.08,Math.max(0,dt));
  // Fixed-step simulation: catch up at most four 60 Hz frames per scheduler tick.
  const n=Math.min(4,Math.floor(accumulator*60));
  accumulator=Math.max(0,accumulator-n/60);
  if(accumulator>1/30)accumulator=0;
  for(const room of rooms.values()){
    if(room.players[0]&&room.players[1]){
      for(let i=0;i<n;i++)room.game.step(1/60,2);
    }
  }
  steps++;
  if(steps%3===0){
    for(const room of rooms.values()){
      if(room.players.some(Boolean)){
        const packet=room.game.snapshot();
        room.players.forEach(p=>p&&p.send(packet));
      }
    }
  }
},1000/60);
tick.unref();
setInterval(()=>{
  for(const peer of connections){
    if(Date.now()-peer.lastSeen>75000)peer.close();else peer.ping();
  }
  for(const [code,room] of rooms){
    if(!room.players.some(Boolean)||Date.now()-room.lastActive>3600000){
      room.players.forEach(p=>p&&p.close());rooms.delete(code);
    }
  }
},30000).unref();
server.listen(PORT,'0.0.0.0',()=>console.log(`Rocket Rivals ready on http://localhost:${PORT}`));
module.exports={server,rooms};
