'use strict';

const WIDTH = 34;
const LENGTH = 50;
const SIDE = WIDTH / 2;
const END = LENGTH / 2;
const GOAL_W = 10.8;
const GOAL_H = 4.5;
const BALL_R = 1.02;
const CAR_R = 1.7;
const MAX_BALL_SPEED = 43;
const MATCH_LENGTH = 180;
const BOOSTS = [
  [-12, -17, 100], [12, 17, 100], [-12, 17, 100], [12, -17, 100],
  [-8, 0, 28], [8, 0, 28], [0, -12, 28], [0, 12, 28],
  [-12, -6, 28], [12, 6, 28], [-12, 6, 28], [12, -6, 28]
];
const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
const norm2 = (x,z) => Math.hypot(x,z) || 1;
const smooth = (current,target,factor) => current+(target-current)*factor;

function makeCar(index) {
  return {
    id: index, x: index === 0 ? -4 : 4, y: .67, z: index === 0 ? 13 : -13,
    yaw: index === 0 ? 0 : Math.PI, pitch:0, roll:0,
    vx:0, vy:0, vz:0, boost:100, grounded:true, jumps:0, jumpLock:false,
    jumpTime:0, dodge:0, boostOn:false,
    input:{throttle:0,steer:0,boost:false,jump:false,handbrake:false,airRoll:0},
    score:0
  };
}

function makeBall() {
  return { x:0,y:BALL_R+.15,z:0,vx:0,vy:0,vz:0,rx:0,rz:0 };
}

class Match {
  constructor() {
    this.cars=[makeCar(0),makeCar(1)];
    this.ball=makeBall();
    this.scores=[0,0];
    this.pads=BOOSTS.map((p,i)=>({id:i,x:p[0],z:p[1],amount:p[2],respawn:0}));
    this.phase='waiting';
    this.phaseTimer=0;
    this.remaining=MATCH_LENGTH;
    this.winner=-1;
    this.lastTouch=-1;
    this.celebration='';
    this.seq=0;
  }
  start() {
    this.scores=[0,0];
    this.remaining=MATCH_LENGTH;
    this.winner=-1;
    this.pads.forEach(p=>p.respawn=0);
    this.resetKickoff();
    this.phase='countdown';
    this.phaseTimer=3.3;
    this.celebration='';
  }
  resetKickoff() {
    this.ball=makeBall();
    this.cars.forEach((car,index)=>{
      const fresh=makeCar(index);
      fresh.boost = index === 0 || index === 1 ? 70 : 70;
      fresh.score=car.score;
      fresh.input=car.input;
      Object.assign(car,fresh);
    });
    this.lastTouch=-1;
  }
  setInput(index, raw) {
    const c=this.cars[index];
    if(!c || !raw || typeof raw!=='object')return;
    c.input={
      throttle:clamp(Number(raw.throttle)||0,-1,1),
      steer:clamp(Number(raw.steer)||0,-1,1),
      boost:raw.boost===true,
      jump:raw.jump===true,
      handbrake:raw.handbrake===true,
      airRoll:clamp(Number(raw.airRoll)||0,-1,1)
    };
  }
  step(dt, activePlayers=2) {
    dt=clamp(dt,0,1/30);
    this.seq++;
    if(activePlayers<2) {
      this.phase='waiting';
      return;
    }
    if(this.phase==='waiting')this.start();
    if(this.phase==='finished') {
      this.phaseTimer-=dt;
      if(this.phaseTimer<=0)this.start();
      return;
    }
    if(this.phase==='goal') {
      this.phaseTimer-=dt;
      if(this.phaseTimer<=0){this.resetKickoff();this.phase='countdown';this.phaseTimer=3.3;}
      return;
    }
    if(this.phase==='countdown') {
      this.phaseTimer-=dt;
      if(this.phaseTimer<=0) {this.phase='playing';this.phaseTimer=0;}
      return;
    }
    if(this.phase!=='playing')return;
    this.remaining=Math.max(0,this.remaining-dt);
    for(const p of this.pads)p.respawn=Math.max(0,p.respawn-dt);
    for(const car of this.cars)this.moveCar(car,dt);
    this.collideCars(this.cars[0],this.cars[1]);
    this.moveBall(dt);
    for(const car of this.cars){
      this.collideCarBall(car);
      this.pickupBoost(car);
    }
    if(this.remaining<=0) {
      this.phase='finished'; this.phaseTimer=8;
      this.winner=this.scores[0]===this.scores[1]?-1:(this.scores[0]>this.scores[1]?0:1);
      this.celebration=this.winner<0?'DRAW!':(this.winner===0?'BLUE WINS!':'ORANGE WINS!');
    }
  }
  moveCar(c,dt) {
    const input=c.input;
    const forwardX=Math.sin(c.yaw),forwardZ=-Math.cos(c.yaw);
    const rightX=Math.cos(c.yaw),rightZ=Math.sin(c.yaw);
    const forwardSpeed=c.vx*forwardX+c.vz*forwardZ;
    const lateralSpeed=c.vx*rightX+c.vz*rightZ;
    const isBoosting=input.boost && c.boost>0 && (!c.grounded || input.throttle>=-.05);
    c.boostOn=isBoosting;
    if(isBoosting)c.boost=Math.max(0,c.boost-31*dt);
    else c.boost=Math.min(100,c.boost+2.3*dt);

    const ground=c.grounded;
    const steeringPower=ground ? (0.65+0.35*clamp(Math.abs(forwardSpeed)/15,0,1)):0.75;
    const direction=forwardSpeed < -1 ? -1 : 1;
    c.yaw += input.steer * 2.85 * steeringPower * direction * (input.handbrake && ground ? 1.50 : 1) * dt;
    // Gravity-free yaw stability and a high-grip but driftable tire model.
    const nx=Math.sin(c.yaw), nz=-Math.cos(c.y);
    const rx=Math.cos(c.yaw), rz=Math.sin(c.yaw);
    const accelerate=ground?48:11;
    const throttle=input.throttle;
    c.vx+=nx * accelerate * throttle *dt;
    c.vz+=nz * accelerate * throttle *dt;
    if(isBoosting){
      const thrust=ground?66:59;
      const facing=ground?1:Math.cos(c.pitch);
      c.vx+=nx*facing*thrust*dt;
      c.vz+=nz*facing*thrust*dt;
      if(!ground)c.vy+=Math.sin(c.pitch)*thrust*dt;
    }
    const side=c.vx*rx+c.vz*rz;
    const grip=ground ? (input.handbrake?1.65:9) : 1.3;
    c.vx-=rx*side*clamp(grip*dt,0,1);
    c.vz-=rz*side*clamp(grip*dt,0,1);
    const drag=ground ? (Math.abs(input.throttle)<.02 && !isBoosting ? 2.3 : 1.08):0.22;
    const dragFactor=Math.exp(-drag*dt);
    c.vx*=dragFactor;c.vz*=dragFactor;
    const maxSpeed=isBoosting?35.5:27.5;
    const speed=norm2(c.vx,c.vz);
    if(speed>maxSpeed){c.vx=c.vx/speed*maxSpeed;c.vz=c.vz/speed*maxSpeed;}

    const pressed=input.jump&&!c.jumpLock;
    if(pressed){
      if(c.grounded){
        c.vy=10.3;c.grounded=false;c.jumps=1;c.jumpTime=0;c.pitch=0;c.roll=0;
      }else if(c.jumps===1 && c.jumpTime<1.5){
        c.vy=Math.max(c.vy,0)+5.0;
        const dodgeF=clamp(input.throttle,-1,1);
        const dodgeS=clamp(input.steer,-1,1);
        let impulseX=nx*(Math.abs(dodgeF)+Math.abs(dodgeS)<.1?1:dodgeF)+rx*dodgeS;
        let impulseZ=nz*(Math.abs(dodgeF)+Math.abs(dodgeS)<.1?1:dodgeF)+rz*dodgeS;
        const len=norm2(impulseX,impulseZ);
        c.vx+=impulseX/len*15;c.vz+=impulseZ/len*15;
        c.jumps=2;c.dodge=.38;
      }
    }
    c.jumpLock=input.jump;
    if(!c.grounded){
      c.jumpTime+=dt;
      c.vy-=24*dt;
      if(c.dodge>0){ c.dodge-=dt;c.pitch-=dt*14; }
      else {
        // Airborne pitch controls the vertical direction of rocket thrust.
        // Air roll is cosmetic for hitbox stability but useful for aerial visuals.
        c.pitch=clamp(c.pitch+input.throttle*1.65*dt,-1.45,1.45);
        c.roll=clamp(c.roll+(input.airRoll||0)*2.3*dt,-Math.PI,Math.PI);
      }
    }else{c.vy=0;c.y=.66;c.pitch=smooth(c.pitch,0,dt*8);c.roll=smooth(c.roll,0,dt*8);}
    c.x+=c.vx*dt;c.y+=c.vy*dt;c.z+=c.vz*dt;
    if(c.y<.66){c.y=.66;c.vy=0;c.grounded=true;c.jumps=0;c.dodge=0;c.pitch=0;c.roll=0;}
    if(c.y>12){c.y=12;if(c.vy>0)c.vy*=-.15;}
    if(c.x>SIDE-1.0){c.x=SIDE-1.0;c.vx=Math.min(0,c.vx)*.38;}
    if(c.x<-SIDE+1.0){c.x=-SIDE+1.0;c.vx=Math.max(0,c.vx)*.38;}
    for(const s of [-1,1]){
      if(c.z*s>END-1.15){
        const insideGoal=Math.abs(c.x)<GOAL_W/2-1.05 && c.y<GOAL_H-0.2;
        const maxZ=insideGoal?END+3.0:END-1.15;
        if(c.z*s>maxZ){c.z=s*maxZ;c.vz=-s*Math.abs(c.vz)*.35;}
      }
    }
  }
  collideCars(a,b){
    if(Math.abs(a.y-b.y)>1.3)return;
    const dx=b.x-a.x,dz=b.z-a.z;
    const distance=norm2(dx,dz);
    if(distance>=3.02)return;
    const nx=dx/distance,nz=dz/distance,correction=(3.02-distance)*.5;
    a.x-=nx*correction;a.z-=nz*correction;
    b.x+=nx*correction;b.z+=nz*correction;
    const rel=(b.vx-a.vx)*nx+(b.vz-a.vz)*nz;
    if(rel<0){const j=-(1+0.55)*rel*.52;
      a.vx-=nx*j;a.vz-=nz*j;
      b.vx+=nx*j;b.vz+=nz*j;
    }
  }
  moveBall(dt){
    const b=this.ball;
    b.vy-=24*dt;
    b.vx*=Math.exp(-.15*dt);
    b.vz*=Math.exp(-.15*dt);
    b.x+=b.vx*dt;b.y+=b.vy*dt;b.z+=b.vz*dt;
    b.rx+=b.vz*dt/BALL_R;
    b.rz-=b.vx*dt/BALL_R;
    if(b.y<BALL_R){b.y=BALL_R;
      if(b.vy<0){b.vy=-b.vy*.72;if(Math.abs(b.vy)<1.25)b.vy=0;}
      b.vx*=Math.exp(-.75*dt);b.vz*=Math.exp(-.75*dt);
    }
    if(b.y>12.5-BALL_R){b.y=12.5-BALL_R;b.vy=-Math.abs(b.vy)*.72;}
    if(b.x>SIDE-BALL_R){b.x=SIDE-BALL_R;b.vx=-Math.abs(b.vx)*.79;}
    if(b.x<-SIDE+BALL_R){b.x=-SIDE+BALL_R;b.vx=Math.abs(b.vx)*.79;}
    const speed=norm2(b.vx,b.vz);
    const total=Math.hypot(b.vx,b.vy,b.vz);
    if(total>MAX_BALL_SPEED){const f=MAX_BALL_SPEED/total;b.vx*=f;b.vy*=f;b.vz*=f;}
    for(const sign of [-1,1]){
      const inGoalMouth=Math.abs(b.x)<GOAL_W/2-BALL_R*.1 && b.y<GOAL_H-BALL_R*.2;
      if(b.z*sign>END+.1 && inGoalMouth){
        const scoringTeam=sign===1?1:0;
        this.scores[scoringTeam]++;
        this.cars[scoringTeam].score++;
        this.phase='goal';this.phaseTimer=2.9;
        this.celebration=sign===1?'ORANGE SCORES!':'BLUE SCORES!';
        return;
      }
      if(b.z*sign>END-BALL_R && !inGoalMouth){
        b.z=sign*(END-BALL_R);
        b.vz=-sign*Math.abs(b.vz)*.78;
      }
      // Bounce against crossbar and goal posts (rounded surfaces).
      for(const xp of [-GOAL_W/2,GOAL_W/2]){
        if(b.y<GOAL_H+.5){
          const dx=b.x-xp,dz=b.z-sign*END;
          const dist=norm2(dx,dz);
          const limit=BALL_R+.3;
          if(dist<limit){
            const nx=dx/dist,nz=dz/dist;
            b.x+=nx*(limit-dist);b.z+=nz*(limit-dist);
            const vn=b.vx*nx+b.vz*nz;
            if(vn<0){b.vx-=(1+.7)*vn*nx;b.vz-=(1+.7)*vn*nz;}
          }
        }
      }
      if(Math.abs(b.z-sign*END)<BALL_R+.25 && Math.abs(b.x)<GOAL_W/2+.25 && Math.abs(b.y-GOAL_H)<BALL_R+.27){
        const dy=b.y-GOAL_H;
        b.y=GOAL_H+Math.sign(dy||1)*(BALL_R+.27);
        b.vy=-b.vy*.6;
      }
    }
  }
  collideCarBall(c){
    const b=this.ball;
    const dx=b.x-c.x,dz=b.z-c.z,dy=b.y-c.y;
    if(Math.abs(dx)>3.6||Math.abs(dz)>3.6||Math.abs(dy)>2.3)return;
    const co=Math.cos(c.yaw),si=Math.sin(c.yaw);
    const lx=dx*co+dz*si;
    const lz=-dx*si+dz*co;
    const qx=clamp(lx,-.99,.99);
    const qz=clamp(lz,-1.69,1.69);
    const qy=clamp(dy,-.57,.57);
    let nxLocal=lx-qx, nzLocal=lz-qz, ny=dy-qy;
    let distance=Math.hypot(nxLocal,nzLocal,ny);
    if(distance>=BALL_R)return;
    if(distance<.001){nxLocal=0;nzLocal=lz<=0?-1:1;ny=.06;distance=1;}
    const nx=(nxLocal*co-nzLocal*si)/distance;
    const nz=(nxLocal*si+nzLocal*co)/distance;
    const ny2=ny/distance;
    const penetration=BALL_R-Math.min(distance,BALL_R);
    b.x+=nx*(penetration+.016);
    b.z+=nz*(penetration+.016);
    b.y=Math.max(BALL_R,b.y+ny2*(penetration+.016));
    const relative=(c.vx-b.vx)*nx+(c.vy-b.vy)*ny2+(c.vz-b.vz)*nz;
    const hit=Math.max(0,relative);
    const extra=c.boostOn?3.9:0;
    const dodge=c.dodge>0?6.5:0;
    const impulse=clamp(hit*1.36+2.9+extra+dodge,0,33);
    b.vx+=nx*impulse;
    b.vy+=ny2*impulse*.85 + (c.grounded?.8:1.15);
    b.vz+=nz*impulse;
    c.vx-=nx*impulse*.045;c.vz-=nz*impulse*.045;
    this.lastTouch=c.id;
    const len=Math.hypot(b.vx,b.vy,b.vz);
    if(len>MAX_BALL_SPEED){const f=MAX_BALL_SPEED/len;b.vx*=f;b.vy*=f;b.vz*=f;}
  }
  pickupBoost(c){
    for(const p of this.pads){
      if(p.respawn<=0 && c.boost<99 && Math.hypot(c.x-p.x,c.z-p.z)<1.95 && c.y<2.5){
        c.boost=Math.min(100,c.boost+p.amount);
        p.respawn=p.amount===100?10:4.5;
      }
    }
  }
  snapshot(){
    return {
      type:'state',phase:this.phase,phaseTimer:Math.max(0,this.phaseTimer),
      remaining:this.remaining,scores:this.scores,winner:this.winner,
      celebration:this.celebration,lastTouch:this.lastTouch,seq:this.seq,
      ball:{...this.ball},
      cars:this.cars.map(c=>({
        id:c.id,x:c.x,y:c.y,z:c.z,yaw:c.yaw,pitch:c.pitch,roll:c.roll,
        vx:c.vx,vy:c.vy,vz:c.vz,boost:c.boost,boostOn:c.boostOn,
        grounded:c.grounded,score:c.score
      })),
      pads:this.pads.map(p=>p.respawn<=0?1:0)
    };
  }
}
module.exports={Match,makeBall,makeCar,WIDTH,LENGTH,GOAL_W,GOAL_H,BALL_R,MATCH_LENGTH};
