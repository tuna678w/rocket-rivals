# 🚀 ROCKET RIVALS — Private 1v1 Car Soccer

A complete original browser-based, 3D car-soccer game with shared physics and private multiplayer room codes. Two friends can play on separate devices. No art assets, graphics CDNs, databases, registration, or third-party Node packages are needed.

## Features

- 3D WebGL arena, stadium, detailed cars, metallic ball, glowing goals and nets
- Dedicated **server-authoritative, fixed 60 Hz** ball and car physics
- Car acceleration, traction, powerslides, steering, directional aerial boost, gravity, jump + second-jump dodges, car/ball collisions, wall and post bounces
- Two-player simultaneous online gameplay over browser WebSockets, ~20 snapshots/second
- **Create Private Room** produces a random five-character code; **Join Room** joins the host's exact game
- One-click invite URL containing the room code (`?room=XXXXX`)
- Scoreboard, 3-minute matches, goal celebrations, countdowns, restart and boost pad respawns
- Keyboard and touch controls; car camera and optional ball camera
- No npm dependencies, no compilation, and no build pipeline

## Play on your computer

Install **Node.js 20 or newer**, then open a terminal *inside this project folder*:

```bash
npm start
```

Open **http://localhost:3000** in your browser. To play from two devices on the same Wi-Fi network, open `http://YOUR-COMPUTER-LAN-IP:3000` on both devices (allow inbound port 3000 if your firewall asks).

**Note:** Localhost alone does *not* let a friend elsewhere on the internet join. For internet play, deploy the Node server as described below.

## Deploy on the internet using Render

Render hosts the WebSocket server **and** website together. The included `render.yaml` is a ready-made deployment configuration.

1. Unzip this project and upload the project contents to a **new GitHub repository** (keep `package.json`, `server/`, `public/`, and `render.yaml` at the root).
2. Sign in to **[render.com](https://render.com/)** and choose **New → Web Service** (or **Blueprint** to use `render.yaml`). Connect the new repository.
3. Choose a Node web service; set **Build Command** to `npm install` and **Start Command** to `npm start`. Choose an available plan. Render automatically sets `PORT` and HTTPS/WSS.
4. Deploy and open the public HTTPS URL Render provides.
5. Click **CREATE PRIVATE ROOM**, then **COPY FRIEND INVITE LINK**. Send that link to your friend; they will automatically join your room. Or send the five-character code and have them enter it manually.

You need a service that supports persistent Node processes and WebSockets. **GitHub Pages or a static-only web host will not run this multiplayer server.** Free hosting tiers, where offered, may sleep when inactive and briefly disconnect active clients on redeploy. The room state is in memory, so server restarts remove all open rooms.

## Controls

| Action | Keyboard | Touchscreen |
|---|---|---|
| Accelerate / reverse | W / S or ↑ / ↓ | Left joystick up/down |
| Steer | A / D or ← / → | Left joystick left/right |
| Boost / aerial thrust | Shift (hold) | BOOST button |
| Powerslide / drift | Ctrl (hold) | — |
| Air roll | Q / E in the air | — |
| Jump | Space | JUMP button |
| Dodge / double jump | Tap Space again while airborne | Tap JUMP again |
| Toggle ball camera | C | Tap camera label at the bottom |

## Testing

```bash
npm test
```

The automated tests cover the server protocol, room joining, browser-client initialization, collisions, gravity, goals, boost refills, jump/dodge, steering, and hostile input handling.

## Project structure

```
public/index.html      Landing screen, room UI, HUD and input controls
public/style.css       Game interface / mobile layout
public/game.js         WebGL 3D renderer, networking and controls
server/index.js        HTTP + WebSocket server, room manager
server/physics.js      Authoritative car/ball physics and game state
render.yaml            Render web-service setup
tests/                 Automated physics, rendering smoke, multiplayer tests
```

**Design note:** This is an independent fan-inspired car-soccer game, not official Rocket League, not affiliated with Epic Games/Psyonix, and it does not use copyrighted game assets. Physics are arcade-style approximations and are not a 1:1 reproduction of the commercial game.
